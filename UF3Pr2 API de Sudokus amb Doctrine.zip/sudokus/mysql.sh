#!/bin/bash

docker exec -it api_sudoku_db mysql -ppassword sudokudb